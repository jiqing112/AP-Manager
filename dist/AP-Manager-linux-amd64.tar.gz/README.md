# AP Manager

x86 Linux 小主机 → 无线路由器。Go 单二进制守护进程 + 内嵌 Web 管理界面。

核心能力：WiFi AP 发射（hostapd）、无线中继（wpa_supplicant STA）、网口角色管理
（WAN/LAN/桥/多网段隔离）、设备管理（DHCP 客户端聚合 / 限速 / 踢下线 / 拉黑）。

## 快速开始

```bash
# 1. 装依赖（hostapd dnsmasq nftables iw 等；探测 apt/dnf/pacman/zypper）
sudo ./scripts/install-deps.sh

# 2. 构建并安装（二进制 + systemd unit + 目录 + 自启）
make build
sudo ./scripts/install.sh

# 3. 打开管理界面（默认监听取自 config.yaml 的 admin 段）
#    首跑初始密码打印在控制台，也存于 /var/lib/apmanager/state.json.initial_password
#    （root-only，首次登录会强制修改）
```

## ⚠️ 当前部署状态（2026-10-08）

- **管理密码当前为 `apmanager2026`** —— 请登录后在「系统」页改成你自己的。
- **WiFi：SSID `AP-Manager`，密码 `apmanager123`**（2.4G 信道 6 / WPA2）——
  可在「热点」页修改频段/信道/加密。
- 上行口 `enx00e04c4b4d10`（有线 DHCP，由 ifupdown 托管）**未纳入管理**（安全红线），
  概览接口列表中显示为「上行·未管理」；如需接管请在「网口」页走安全应用流程。
- 本机网卡 RTL8821CE 驱动未声明 AP+STA 并存：**中继与 AP 互斥**（开启一个会停另一个）。

## 管理界面

| 页面 | 功能 |
|---|---|
| 概览 | AP/上游/设备/CPU 一览、实时流量折线图（2s 刷新）、接口速览、AP 快捷启停 |
| 热点 | SSID/密码/加密(WPA2/WPA3/混合)/频段/信道/频宽/隐藏/最大客户端 |
| 中继 | 扫描周围 WiFi、连接上游、自动重连（退避+切换次优先级）、已存上游管理 |
| 设备 | 备注别名、双向限速（tc HTB）、踢下线、拉黑（nft+dnsmasq+hostapd 三层） |
| 网口 | 角色分配（WAN: DHCP/静态/PPPoE、LAN 挂桥）、多 LAN 网段、**安全应用**（60s 未确认自动回滚） |
| 系统 | CPU/内存/温度、修改管理密码、托管进程状态 |
| 日志 | 应用日志（级别过滤/暂停滚动）+ 子进程诊断面板（hostapd/dnsmasq stderr 尾部） |

数据通道：登录后一个 SSE 连接（`/api/events`）推全部实时数据，页面不轮询。

## 手机实测步骤

见 `NEEDUSER.md`（需要物理操作的验收项清单）：连 WiFi 拿 192.168.50.x、限速精度、
踢下线/黑名单、断电重启自动恢复等。

## 运维

```bash
systemctl status|restart|stop apmanager
journalctl -u apmanager -f          # journald 与文件日志双写
tail -f /var/log/apmanager/app.log  # 轮转：10MB × 3 份
nft list table inet apmanager       # 自家防火墙表（绝不触碰其他表）
sudo ./scripts/uninstall.sh         # 卸载（--purge 连配置状态一起删）
```

**RTL8821CE 稳定性**：install.sh 检测到该网卡时自动写入 `/etc/modprobe.d/rtw88.conf`
（`rtw88_pci disable_aspm=1` 消除随机掉卡，实测生效；`rtw88_core disable_lps_deep=Y`
缓解深度省电掉速，**需重启一次才生效**）。驱动重载/掉卡后接口重建的场景由对账循环
兜底：LAN 地址 5s 内自动补配、hostapd 自动重拉。

配置：`/etc/apmanager/config.yaml`（期望态；守护进程每 5s 对账收敛——AP 挂了自动拉起、
WAN 掉址自动补拉）。状态（密码哈希/别名/黑名单/限速表）：`/var/lib/apmanager/state.json`。

## 架构（一览）

```
Web UI (Tailwind+Alpine+Chart.js, go:embed)
  └─ HTTP API + SSE
      └─ ap / relay / ethport / netrt / devices / system
          └─ iface（统一接口抽象 + iw 能力探测）
              └─ priv（唯一特权层：exec/netlink/nft/tc）
                  └─ hostapd / dnsmasq / wpa_supplicant / pppd / nft / tc
```

构建：`make build`（Tailwind CSS → go build，embed 进单二进制）。
开发 UI：`make dev`（假数据模式，不动系统）。
测试：`go test ./...`（hostapd/dnsmasq/nft 渲染单测）。

## 已知限制

- 多 WAN 负载均衡未实现（单网口机器无法实测；上游健康探测与优先级切换已具备）。
- IPv6 仅架构预留（nft inet 表 + dnsmasq 扩展位）。
- 无线中继与 AP 共存依赖网卡能力；本机网卡为互斥模式（UI 有明确提示）。
